let report = require('./reporter');
let env = require('./getEnvironment');
let userDetails = require('./getUserDetails');
let cbt = require('./cbt');

function getEnvironment() {
    return env.getEnvironment();
}

function postReports(slackOptions, reportOptions, done) {
    report.generate(slackOptions, reportOptions, done);
}

function cucumberReport(reportOptions, done) {
    report.cucumberReport(reportOptions, done);
}

function getUserDetails(userType) {
    let userData =  userDetails.getUserDetails(userType);
    return userData;
}

function getUserName(userType) {
    let userName =  userDetails.getUserName(userType);
    return userName;
}

function getPassword(userType) {
    let password =  userDetails.getPassword(userType);
    return password;
}

function getCustomerId(userType) {
    let customerID =  userDetails.getCustomerId(userType);
    return customerID;
}

function getLoanNumber(userType) {
    let loanNumber =  userDetails.getLoanNumber(userType);
    return loanNumber;
}

function getLeadId(userType) {
    let leadId =  userDetails.getLeadId(userType);
    return leadId;
}

function getSsn(userType) {
    let ssn =  userDetails.getSsn(userType);
    return ssn;
}

function get4digitSsn(userType) {
    let fourDigitSsn =  userDetails.get4digitSsn(userType);
    return fourDigitSsn;
}

function getPostalZipCode(userType) {
    let postalZipCode =  userDetails.getPostalZipCode(userType);
    return postalZipCode;
}

function getRoutingNumber(userType) {
    let routingNumber =  userDetails.getRoutingNumber(userType);
    return routingNumber;
}

function getEmail(userType) {
    let email =  userDetails.getEmail(userType);
    return email;
}

function setCbtScore(sessionId, score) {
    return cbt.setCbtScore(sessionId, score);
}

module.exports = {
    getEnvironment,
    postReports,
    cucumberReport,
    getUserName,
    getPassword,
    getCustomerId,
    getLoanNumber,
    getLeadId,
    getSsn,
    get4digitSsn,
    getPostalZipCode,
    getRoutingNumber,
    getEmail,
    getUserDetails,
    setCbtScore
};
