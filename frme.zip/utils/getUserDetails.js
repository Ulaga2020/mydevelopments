'use strict';

let env = require('./getEnvironment');
let qaTestData = require('../resources/qaTestData');
let uatTestData = require('../resources/uatTestData');

let getTestJsonData =  function (userType) {
    let data = {};
    let environments = env.getEnvironment();
    if (!environments.length > 0){
        data = qaTestData;
        return data;
    } else {
        environments.forEach(function(env){
            if(env.includes('qa')) {
                 data = qaTestData;
                return data;
            } else if(env.includes('uat')) {
                 data = uatTestData;
                return data;
            } else {
                console.log('No such Environment')
            }
        });
        return data;
    }
};

let getUserDetails =  function (userType) {
    let data =  getTestJsonData(userType);
    switch (userType) {
        case 'singleBorrower':
            return data.singleBorrower;
            break;

        case 'dualBorrower':
            return data.dualBorrower;
            break;

        default:
            console.log("No Such test data available in JSON")
    }
};

let getUserName =  function (userType) {
    let userData =  getUserDetails(userType);
    return userData['userName'];
};

let getPassword =  function (userType) {
    let userData =  getUserDetails(userType);
    return userData['password'];
};

let getCustomerId =  function (userType) {
    let userData =  getUserDetails(userType);
    return userData['customerId'];
};

let getLeadId=  function (userType) {
    let userData =  getUserDetails(userType);
    return userData['leadId'];
};

let getLoanNumber =  function (userType) {
    let userData =  getUserDetails(userType);
    return userData['loanNumber'];
};

let getSsn =  function (userType) {
    let userData =  getUserDetails(userType);
    return userData['ssn'];
};

let get4digitSsn =  function (userType) {
    let userData =  getUserDetails(userType);
    return userData['last4DigitSsn'];
};

let getPostalZipCode =  function (userType) {
    let userData =  getUserDetails(userType);
    return userData['postalZipCode'];
};

let getRoutingNumber =  function (userType) {
    let userData =  getUserDetails(userType);
    return userData['routingNumber'];
};

let getEmail =  function (userType) {
    let userData =  getUserDetails(userType);
    return userData['email'];
};

module.exports = {
    getUserDetails: getUserDetails,
    getUserName: getUserName,
    getPassword: getPassword,
    getCustomerId: getCustomerId,
    getLoanNumber: getLoanNumber,
    getLeadId: getLeadId,
    getSsn: getSsn,
    get4digitSsn: get4digitSsn,
    getPostalZipCode: getPostalZipCode,
    getRoutingNumber: getRoutingNumber,
    getEmail: getEmail
};
