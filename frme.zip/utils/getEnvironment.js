function getEnvironment() {
    let environment = [];
    process.argv.forEach((value, index) => {
        if (value == '-e' || value == '-env') {
            environment.push(process.argv[index + 1])
        }
    });
    return environment;
}

module.exports = {
    getEnvironment
}
