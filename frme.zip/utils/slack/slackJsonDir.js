'use strict';

let jsonFile = require('jsonfile');
let find = require('find');

let collectJSONS = function (options) {
    let jsonOutput = [];
    let files;

    try {
        files = find.fileSync(/\.json$/, options.jsonDir);
    } catch (e) {
        throw new Error('\'options.jsonDir\' does not exist. ' + e);
    }

    if (files.length === 0) throw new Error('No JSON files found under \'options.jsonDir\': ' + options.jsonDir);

    function mergeJSONS(file) {
        let cucumberJson = jsonFile.readFileSync(file);

        function collect(json) {
            jsonOutput.push(json);
        }

        if ((!cucumberJson || typeof cucumberJson[0] === 'undefined') && !options.ignoreBadJsonFile) {
            throw new Error('Invalid Cucumber JSON file found under ' + options.jsonDir + ': ' + file);
        } else if ((!cucumberJson || typeof cucumberJson[0] === 'undefined') && options.ignoreBadJsonFile) {
            console.log('Invalid Cucumber JSON file found under ' + options.jsonDir + ': ' + file);
        }
        else {
            cucumberJson.map(collect)
        }
    }

    files.map(mergeJSONS);

    jsonFile.writeFileSync(options.output + '.json', jsonOutput, {spaces: 2});

    return jsonOutput;
};

module.exports = {
    collectJSONS: collectJSONS
};
