'use strict';

let jsonFile = require('jsonfile');
let _ = require('lodash');
let fs = require('fs-extra');
let path = require('path');
let jsonDir = require('./slack/slackJsonDir');
let opn = require('opn');
let searchFileUp = require('./slack/slackSearchFileUp');
let hierarchyReporter = require('./slack/slackHierarchyReporter');
let IncomingWebhook = require('@slack/client').IncomingWebhook;
let assign = require('object-assign');
let htmlReporter = require('cucumber-html-reporter');

let calculateDuration = function (durationInNanoSeconds) {
    // convert it to MILLI_SECONDS
    let durationInMillis = _.floor(durationInNanoSeconds / 1000000);

    let oneMilliSecond = 1000;
    let oneMinute = 60 * oneMilliSecond;
    let formattedDuration = '0s';

    function format(min, sec, ms) {
        let MINUTES = 'm ';
        let SECONDS = 's ';
        let MILLI_SECONDS = 'ms';
        let formattedTimeStamp = '';

        min > 0 ? formattedTimeStamp += min + MINUTES : '';
        sec > 0 ? formattedTimeStamp += sec + SECONDS : '';
        ms > 0 ? formattedTimeStamp += ms + MILLI_SECONDS : '';

        return formattedTimeStamp.trim().length === 0 ? '< 1ms' : formattedTimeStamp;
    }

    if (!isNaN(durationInMillis)) {

        let min = _.floor(durationInMillis / oneMinute);
        let sec = _.floor((durationInMillis % oneMinute) / oneMilliSecond);
        let ms = durationInMillis % oneMilliSecond;

        formattedDuration = format(min, sec, ms);
    }

    return formattedDuration;
};

let featureResults = function (json) {
    let featureOutput = jsonFile.readFileSync(json);
    let packageJsonPath = searchFileUp('package.json');
    let packageJson = {};
    try {
        packageJson = packageJsonPath && jsonFile.readFileSync(packageJsonPath, 'utf8');
    } catch (err) {
        console.warn('No package.json file found in: ' + packageJsonPath + ', using default name and version.');
        packageJson.name = 'default';
        packageJson.version = '0.0.0';
    }

    let sanitize = function (name, find) {
        let unsafeCharacters = find || /[\/\\\|:"\*\?<>]/g;
        name = name.trim().replace(unsafeCharacters, '_');
        return name;
    };

    featureOutput.summary = {
        isFailed: false,
        passed: 0,
        failed: 0,
        ambiguous: 0,
        skipped: 0,
        notdefined: 0,
        pending: 0
    };

    let result = {
        status: {
            passed: 'passed',
            failed: 'failed',
            skipped: 'skipped',
            pending: 'pending',
            undefined: 'undefined',
            ambiguous: 'ambiguous'
        }
    };

    let suite = {
        name: {
            plain: packageJson && packageJson.name,
            sanitized: sanitize(packageJson && packageJson.name, /[^a-z|0-9]/g)
        },
        brandTitle: packageJson.name,
        version: packageJson && packageJson.version,
        time: new Date(),
        features: featureOutput,
        passed: 0,
        failed: 0,
        ambiguous: 0,
        totalTime: 0,
        suites: [],
        scenarios: {
            passed: 0,
            failed: 0,
            skipped: 0,
            pending: 0,
            notdefined: 0,
            ambiguous: 0
        }
    };

    function getColumnLayoutWidth() {
        const FULL_WIDTH = 12;
        const HALF_WIDTH = 6;
    }

    let preventOverlappingTheScenarioTitle = function (element) {
        let counter = 0;

        if (element.passed) counter++;
        if (element.notdefined) counter++;
        if (element.pending) counter++;
        if (element.skipped) counter++;
        if (element.failed) counter++;
        if (element.ambiguous) counter++;

        counter = (counter * 20) + 10;

        return counter + 'px';
    };
    let setStats = function (suite) {
        let featureOutput = suite.features;
        let topLevelFeatures = [];
        let featuresSummary = suite.features.summary;
        let screenshotsDirectory;
        suite.reportAs = 'Features';

        let basedir = hierarchyReporter.getBaseDir(suite);

        featureOutput.forEach(function (feature) {
            feature.hierarchy = hierarchyReporter.getFeatureHierarchy(feature.uri, basedir);
            feature.scenarios = {};
            feature.scenarios.passed = 0;
            feature.scenarios.failed = 0;
            feature.scenarios.notdefined = 0;
            feature.scenarios.skipped = 0;
            feature.scenarios.pending = 0;
            feature.scenarios.ambiguous = 0;
            feature.scenarios.count = 0;
            feature.time = 0;
            featuresSummary.isFailed = false;
            featuresSummary.isAmbiguous = false;

            if (!feature.elements) {
                return;
            }

            feature.elements.forEach(function (element) {
                element.passed = 0;
                element.failed = 0;
                element.notdefined = 0;
                element.skipped = 0;
                element.pending = 0;
                element.ambiguous = 0;
                element.time = 0;

                if (element.type === 'background') {
                    return;
                }

                element.steps.forEach(function (step) {
                    if (step.embeddings !== undefined) {
                        step.embeddings.forEach(function (embedding) {

                            let embeddingType = {};

                            if (embedding.mime_type) {
                                embeddingType = embedding.mime_type;
                            } else if (embedding.media) {
                                embeddingType = embedding.media.type;
                            }

                            if (embeddingType === 'text/plain' || embeddingType === 'text/html') {

                                let decoded;

                                if (embeddingType === 'text/html') {
                                    decoded = new Buffer(embedding.data, 'base64').toString('ascii');
                                } else {
                                    decoded = embedding.data;
                                }

                                if (!step.text) {
                                    step.text = decoded;
                                } else {
                                    step.text = step.text.concat('<br>' + embedding.data);
                                }
                            } else if (embeddingType === 'application/json') {
                                let decoded = new Buffer(embedding.data, 'base64').toString('ascii');

                                if (!step.text) {
                                    step.text = decoded;
                                } else {
                                    step.text = step.text.concat('<br>' + decoded);
                                }
                            } else if (embeddingType === 'image/png') {
                                step.image = 'data:image/png;base64,' + embedding.data;
                            } else {
                                let file = 'data:application/octet-stream;base64,' + embedding.data;
                                let fileType = embedding.mime_type.split('/')[1];
                                step.text = step.text || '';
                                step.text = step.text.concat('<a href="' + file + '" download="file.' + fileType + '">download file</a>');
                            }
                        });
                    }

                    if (!step.result || (step.hidden && !step.text && !step.image)) {
                        return 0;
                    }

                    if (step.result.duration) element.time += step.result.duration;

                    if (step.result.status === result.status.passed) {
                        return element.passed++;
                    }
                    if (step.result.status === result.status.failed) {
                        return element.failed++;
                    }
                    if (step.result.status === result.status.undefined) {
                        return element.notdefined++;
                    }
                    if (step.result.status === result.status.pending) {
                        return element.pending++;
                    }
                    if (step.result.status === result.status.ambiguous) {
                        return element.ambiguous++;
                    }

                    element.skipped++;
                });

                if (element.time > 0) {
                    feature.time += element.time;
                }

                feature.scenarios.count++;

                if (element.failed > 0) {
                    feature.scenarios.failed++;
                    featuresSummary.isFailed = true;
                    return suite.scenarios.failed++;
                }

                if (element.ambiguous > 0) {
                    feature.scenarios.ambiguous++;
                    featuresSummary.isAmbiguous = true;
                    return suite.scenarios.ambiguous++;
                }

                if (element.notdefined > 0) {
                    feature.scenarios.notdefined++;
                    return suite.scenarios.notdefined++;
                }

                if (element.pending > 0) {
                    feature.scenarios.pending++;
                    return suite.scenarios.pending++;
                }

                if (element.skipped > 0) {
                    feature.scenarios.skipped++;
                    return suite.scenarios.skipped++;
                }

                if (element.passed > 0) {
                    feature.scenarios.passed++;
                    return suite.scenarios.passed++;
                }

            });

            let subSuite = undefined;
            if (subSuite) {
                subSuite.features.push(feature);
            } else {
                topLevelFeatures.push(feature);
            }

            if (featuresSummary.isFailed) {
                featuresSummary.failed++;
                subSuite ? hierarchyReporter.recursivelyIncrementStat(subSuite, 'failed') : suite.failed++;
            } else if (featuresSummary.isAmbiguous) {
                featuresSummary.ambiguous++;
                subSuite ? hierarchyReporter.recursivelyIncrementStat(subSuite, 'ambiguous') : suite.ambiguous++;
            } else if (feature.scenarios.count === feature.scenarios.skipped) {
                featuresSummary.skipped++;
                subSuite ? hierarchyReporter.recursivelyIncrementStat(subSuite, 'passed') : suite.passed++;
            } else if (feature.scenarios.count === feature.scenarios.notdefined) {
                featuresSummary.notdefined++;
                subSuite ? hierarchyReporter.recursivelyIncrementStat(subSuite, 'passed') : suite.passed++;
            } else if (feature.scenarios.count === feature.scenarios.pending) {
                featuresSummary.pending++;
                subSuite ? hierarchyReporter.recursivelyIncrementStat(subSuite, 'passed') : suite.passed++;
            } else {
                featuresSummary.passed++;
                subSuite ? hierarchyReporter.recursivelyIncrementStat(subSuite, 'passed') : suite.passed++;
            }


            if (feature.time) {
                suite.totalTime += feature.time
            }

            suite.features = topLevelFeatures;
            suite.features.summary = featuresSummary;

            return suite;

        });

        suite.totalTime = calculateDuration(suite.totalTime);

        return suite;
    };

    let featureResult = setStats(suite);
    return featureResult;

}

let generateReport = function (slackOptions, reportOptions, done) {

    let featureOutput = jsonFile.readFileSync(slackOptions.jsonFile);
    let packageJsonPath = searchFileUp('package.json');
    let packageJson = {};
    try {
        packageJson = packageJsonPath && jsonFile.readFileSync(packageJsonPath, 'utf8');
    } catch (err) {
        console.warn('No package.json file found in: ' + packageJsonPath + ', using default name and version.');
        packageJson.name = 'default';
        packageJson.version = '0.0.0';
    }

    let sanitize = function (name, find) {
        let unsafeCharacters = find || /[\/\\\|:"\*\?<>]/g;
        name = name.trim().replace(unsafeCharacters, '_');
        return name;
    };

    featureOutput.summary = {
        isFailed: false,
        passed: 0,
        failed: 0,
        ambiguous: 0,
        skipped: 0,
        notdefined: 0,
        pending: 0
    };

    let result = {
        status: {
            passed: 'passed',
            failed: 'failed',
            skipped: 'skipped',
            pending: 'pending',
            undefined: 'undefined',
            ambiguous: 'ambiguous'
        }
    };

    let suite = {
        name: {
            plain: slackOptions.name || packageJson && packageJson.name,
            sanitized: sanitize(slackOptions.name || packageJson && packageJson.name, /[^a-z|0-9]/g)
        },
        brandTitle: slackOptions.brandTitle,
        version: packageJson && packageJson.version,
        time: new Date(),
        features: featureOutput,
        passed: 0,
        failed: 0,
        ambiguous: 0,
        totalTime: 0,
        suites: [],
        scenarios: {
            passed: 0,
            failed: 0,
            skipped: 0,
            pending: 0,
            notdefined: 0,
            ambiguous: 0
        }
    };

    function getColumnLayoutWidth() {
        const FULL_WIDTH = 12;
        const HALF_WIDTH = 6;

        if (slackOptions.columnLayout === 1) {
            return FULL_WIDTH;
        } else {
            return HALF_WIDTH;
        }
    }

    let preventOverlappingTheScenarioTitle = function (element) {
        let counter = 0;

        if (element.passed) counter++;
        if (element.notdefined) counter++;
        if (element.pending) counter++;
        if (element.skipped) counter++;
        if (element.failed) counter++;
        if (element.ambiguous) counter++;

        counter = (counter * 20) + 10;

        return counter + 'px';
    };

    let setStats = function (suite) {
        let featureOutput = suite.features;
        let topLevelFeatures = [];
        let featuresSummary = suite.features.summary;
        let screenshotsDirectory;
        suite.reportAs = 'Features';

        if (slackOptions.screenshotsDirectory) {
            screenshotsDirectory = slackOptions.screenshotsDirectory;
        } else {
            screenshotsDirectory = slackOptions.output ? path.join(slackOptions.output, '..', 'screenshots') : 'screenshots';
        }

        let basedir = hierarchyReporter.getBaseDir(suite);

        featureOutput.forEach(function (feature) {
            feature.hierarchy = hierarchyReporter.getFeatureHierarchy(feature.uri, basedir);
            feature.scenarios = {};
            feature.scenarios.passed = 0;
            feature.scenarios.failed = 0;
            feature.scenarios.notdefined = 0;
            feature.scenarios.skipped = 0;
            feature.scenarios.pending = 0;
            feature.scenarios.ambiguous = 0;
            feature.scenarios.count = 0;
            feature.time = 0;
            featuresSummary.isFailed = false;
            featuresSummary.isAmbiguous = false;

            if (!feature.elements) {
                return;
            }

            feature.elements.forEach(function (element) {
                element.passed = 0;
                element.failed = 0;
                element.notdefined = 0;
                element.skipped = 0;
                element.pending = 0;
                element.ambiguous = 0;
                element.time = 0;

                if (element.type === 'background') {
                    return;
                }

                element.steps.forEach(function (step) {
                    if (step.embeddings !== undefined) {
                        step.embeddings.forEach(function (embedding) {

                            let embeddingType = {};

                            if (embedding.mime_type) {
                                embeddingType = embedding.mime_type;
                            } else if (embedding.media) {
                                embeddingType = embedding.media.type;
                            }

                            if (embeddingType === 'text/plain' || embeddingType === 'text/html') {

                                let decoded;

                                if (embeddingType === 'text/html') {
                                    decoded = new Buffer(embedding.data, 'base64').toString('ascii');
                                } else {
                                    decoded = embedding.data;
                                }

                                if (!step.text) {
                                    step.text = decoded;
                                } else {
                                    step.text = step.text.concat('<br>' + embedding.data);
                                }
                            } else if (embeddingType === 'application/json') {
                                let decoded = new Buffer(embedding.data, 'base64').toString('ascii');

                                if (!step.text) {
                                    step.text = decoded;
                                } else {
                                    step.text = step.text.concat('<br>' + decoded);
                                }
                            } else if (embeddingType === 'image/png') {
                                step.image = 'data:image/png;base64,' + embedding.data;

                                if ((slackOptions.storeScreenshots && slackOptions.storeScreenshots === true) ||
                                    (slackOptions.storeScreenShots && slackOptions.storeScreenShots === true)) {

                                    let name = sanitize(step.name || step.keyword);
                                    if (!fs.existsSync(screenshotsDirectory)) {
                                        fs.mkdirSync(screenshotsDirectory);
                                    }
                                    name = name + '_' + Math.round(Math.random() * 10000) + '.png'; //randomize the file name
                                    let filename = path.join(screenshotsDirectory, name);
                                    fs.writeFileSync(filename, embedding.data, 'base64');
                                }
                            } else {
                                let file = 'data:application/octet-stream;base64,' + embedding.data;
                                let fileType = embedding.mime_type.split('/')[1];
                                step.text = step.text || '';
                                step.text = step.text.concat('<a href="' + file + '" download="file.' + fileType + '">download file</a>');
                            }
                        });
                    }

                    if (!step.result || (step.hidden && !step.text && !step.image)) {
                        return 0;
                    }

                    if (step.result.duration) element.time += step.result.duration;

                    if (step.result.status === result.status.passed) {
                        return element.passed++;
                    }
                    if (step.result.status === result.status.failed) {
                        return element.failed++;
                    }
                    if (step.result.status === result.status.undefined) {
                        return element.notdefined++;
                    }
                    if (step.result.status === result.status.pending) {
                        return element.pending++;
                    }
                    if (step.result.status === result.status.ambiguous) {
                        return element.ambiguous++;
                    }

                    element.skipped++;
                });

                if (element.time > 0) {
                    feature.time += element.time;
                }

                feature.scenarios.count++;

                if (element.failed > 0) {
                    feature.scenarios.failed++;
                    featuresSummary.isFailed = true;
                    return suite.scenarios.failed++;
                }

                if (element.ambiguous > 0) {
                    feature.scenarios.ambiguous++;
                    featuresSummary.isAmbiguous = true;
                    return suite.scenarios.ambiguous++;
                }

                if (element.notdefined > 0) {
                    feature.scenarios.notdefined++;
                    return suite.scenarios.notdefined++;
                }

                if (element.pending > 0) {
                    feature.scenarios.pending++;
                    return suite.scenarios.pending++;
                }

                if (element.skipped > 0) {
                    feature.scenarios.skipped++;
                    return suite.scenarios.skipped++;
                }

                if (element.passed > 0) {
                    feature.scenarios.passed++;
                    return suite.scenarios.passed++;
                }

            });

            let subSuite = undefined;
            if (slackOptions.theme === 'hierarchy') {
                subSuite = hierarchyReporter.findOrCreateSubSuite(suite, feature.hierarchy);
            }
            if (subSuite) {
                subSuite.features.push(feature);
            } else {
                topLevelFeatures.push(feature);
            }

            if (featuresSummary.isFailed) {
                featuresSummary.failed++;
                subSuite ? hierarchyReporter.recursivelyIncrementStat(subSuite, 'failed') : suite.failed++;
            } else if (featuresSummary.isAmbiguous) {
                featuresSummary.ambiguous++;
                subSuite ? hierarchyReporter.recursivelyIncrementStat(subSuite, 'ambiguous') : suite.ambiguous++;
            } else if (feature.scenarios.count === feature.scenarios.skipped) {
                featuresSummary.skipped++;
                subSuite ? hierarchyReporter.recursivelyIncrementStat(subSuite, 'passed') : suite.passed++;
            } else if (feature.scenarios.count === feature.scenarios.notdefined) {
                featuresSummary.notdefined++;
                subSuite ? hierarchyReporter.recursivelyIncrementStat(subSuite, 'passed') : suite.passed++;
            } else if (feature.scenarios.count === feature.scenarios.pending) {
                featuresSummary.pending++;
                subSuite ? hierarchyReporter.recursivelyIncrementStat(subSuite, 'passed') : suite.passed++;
            } else {
                featuresSummary.passed++;
                subSuite ? hierarchyReporter.recursivelyIncrementStat(subSuite, 'passed') : suite.passed++;
            }

            if (slackOptions.reportSuiteAsScenarios) {
                suite.failed = suite.scenarios.failed;
                suite.passed = suite.scenarios.passed;
                suite.ambiguous = suite.scenarios.ambiguous;
                suite.reportAs = 'scenarios';
            }

            if (feature.time) {
                suite.totalTime += feature.time
            }

            suite.features = topLevelFeatures;
            suite.features.summary = featuresSummary;

            return suite;

        });

        suite.totalTime = calculateDuration(suite.totalTime);

        /*       if (slackOptions.theme === 'hierarchy') {
                   setupSubSuiteTemplates(suite);
               }*/

        if (slackOptions.metadata) suite.metadata = slackOptions.metadata;

        return suite;
    };

    suite = setStats(suite);
    let webhookURL = process.env.SLACK_WEBHOOK_URL || slackOptions.slack_webhook_url || (slackOptions.globals || {}).slack_webhook_url
        ,
        sendOnlyOnFailure = slackOptions.slack_send_only_on_failure || (slackOptions.globals || {}).slack_slack_send_only_on_failure || false
        ,
        sendOnlyFailedTests = slackOptions.slack_send_only_failed_tests || (slackOptions.globals || {}).slack_send_only_failed_tests || false
        , features = suite.features || {}
        , attachments = []
        , message, wh, scenarios, skipped, color
    ;
    if (!webhookURL) {
        console.warn('[slack-reporter] Slack Web-hook URL is not configured.');
        return done();
    }
    wh = new IncomingWebhook(webhookURL);

    if (sendOnlyOnFailure && suite.failed < 1) {
        return done();
    }

    message = slackOptions.slack_message || (slackOptions.globals || {}).slack_message || {};
    if (typeof message === 'function') {
        message = message.apply(this, [suite, slackOptions]);
    }
    if (typeof message === 'string') {
        message = {text: message};
    }

    features.forEach(feature => {
        let featureName = 'Feature: ' + feature.name || {}
            , scenarios = feature.elements || {}
            , fields = []
        ;
        scenarios.forEach(function (scenario) {
            let scenarioName = 'Scenario: ' + scenario.name
                , skipped = scenario.skipped > 0
                , failed = scenario.failed > 0
                , steps = scenario.steps || []
                , color = failed ? 'danger' : skipped ? 'warning' : 'good'
                , text = steps.length + ' Steps, ' + calculateDuration(scenario.time) + ' seconds elapsed'
                , fields = []
            ;

            if (slackOptions.slack_send_only_on_failure) {
                attachments.push({
                    color: color,
                    title: featureName,
                    footer: text,
                    text: scenarioName,
                    fields: fields
                });
            }

            if (!slackOptions.slack_send_only_on_failure) {
                attachments.push({
                    color: color,
                    title: featureName,
                    footer: text,
                    text: scenarioName,
                    fields: fields
                });
            }
        });
    });

    wh.send(assign({
        attachments: attachments
    }, message), function (err, res) {
        htmlReporter.generate(reportOptions, done);
        if (err) {
            console.log('Error:', err);
        } else {
            console.log('Message sent: ', res);
        }
        done();
    });

    console.log('Cucumber Slack Notification Posted.');
};

function generate(slackOptions, reportOptions, done) {

    function isValidJsonFile() {
        slackOptions.jsonFile = slackOptions.jsonFile || slackOptions.output + '.json';

        try {
            JSON.parse(JSON.stringify(jsonFile.readFileSync(slackOptions.jsonFile)));
            return true;
        } catch (e) {
            console.error('Unable to parse cucumberjs output into json: \'%s\'', slackOptions.jsonFile, e);
            if (callback) {
                callback('Unable to parse cucumberjs output into json: \'' + slackOptions.jsonFile + '\'. Error: ' + e);
            } else {
                return false;
            }
        }
    }

    if (slackOptions.jsonDir) {
        jsonDir.collectJSONS(slackOptions, callback)
    }

    if (isValidJsonFile()) {
        generateReport(slackOptions, reportOptions, done);
    }

}

function cucumberReport(reportOptions, done) {
    htmlReporter.generate(reportOptions, done);
}

module.exports = {
    generate: generate,
    cucumberReport: cucumberReport,
    featureResults: featureResults
};
