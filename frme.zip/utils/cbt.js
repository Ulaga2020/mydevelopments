'use strict';
let request = require('request');
let username = 'Bavani.soma@mrcooper.com';
let authKey = 'uaaa0874fb81955b';
let sessionId = null;

function setCbtScore(sessionId, score) {
    return new Promise((resolve, reject) => {
        request({
                method: 'PUT',
                uri: 'https://crossbrowsertesting.com/api/v3/selenium/' + sessionId,
                body: {"action": "set_score", "score": score},
                json: true
            },
            function (error, response, body) {
                if (error) reject(error);
                if (response.statusCode != 200) {
                    reject('Invalid status code <' + response.statusCode + '>');
                }
                resolve(body);
            })
            .auth(username, authKey);
    });
}

module.exports = {
    setCbtScore: setCbtScore
}
