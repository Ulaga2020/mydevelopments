let utils = require('./utils');
let cucumberReport = true;
let environments = utils.getEnvironment();
let slackOptions = {
    jsonFile: 'reports/cucumber.json',
    reportSuiteAsScenarios: true,
    slack_message: function (results) {
        return {
            text: 'Test completed, Passed Scenarios: ' + results.scenarios.passed + ', Failed Scenarios: ' + results.scenarios.failed + ', Skipped Scenarios: ' + results.scenarios.skipped,
            username: environments[0] +' --> ' + results.time.toDateString(),
        }
    },
    slack_webhook_url: 'https://hooks.slack.com/services/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'

};
let reportOptions = {
    theme: 'bootstrap',
    jsonFile: 'reports/cucumber.json',
    output: 'reports/cucumber.html',
    reportSuiteAsScenarios: true,
    launchReport: false,
    storeScreenShots: false,
};

module.exports = {
    utils: utils,
    waitForConditionTimeout: 20000,
    waitForConditionPollInterval: 300,
    loanDetails: {},
    before: function (done) {
        console.log('<----------HI - Sales Desk Web Application Automation Starts---------->');
        try {
            if ((this.test_settings.launch_url).includes('mrcooper.com')) {
                console.log('Valid HI URL')
            }
        } catch (e) {
            console.log('URL is Invalid' + e)
        }
        done();
    },

    after: function (done) {
        console.log('<----------Test Suite Ends---------->');
        if (this.test_settings.slack_notification && cucumberReport) {
            utils.postReports(slackOptions, reportOptions, done);
        } else if (cucumberReport) {
            utils.cucumberReport(reportOptions, done);
        } else {
            done();
        }
    }
};
