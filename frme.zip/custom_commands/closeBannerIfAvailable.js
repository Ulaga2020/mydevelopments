'use strict';
const {client} = require('nightwatch-cucumber');
module.exports.command = function () {
    return this.elements('css selector', 'div[id$="-banner-modal"]', results => {
        if (results.status !== 0) {
            console.log(results.errmessages);
        }
        if (results.value.length > 0) {
            client.click('css selector', 'div.modal-content_message > a.close-button');
        }
    });
};
