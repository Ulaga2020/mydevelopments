'use strict';
const {client} = require('nightwatch-cucumber');
const {When} = require('cucumber');

let homePage = client.page.homePage();

When(/^I am in home page$/, () => {
    homePage.navigate(client.globals.launchUrl);
    return homePage;
});
