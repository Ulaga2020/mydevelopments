'use strict';
const {client} = require('nightwatch-cucumber');
const {When, Then} = require('cucumber');
let utils = require('./../utils');

Then(/^I close any banner if available$/, () => {
    client.isPresent('div[id$="-modal"]', function (banner) {
        if (banner == true) {
            client.click('div.modal-content_message > a.close-button');
            return client;
        } else {
            return client;
        }
    })
});

When(/^I get "([^"]*)" details$/, (userType) => {
    let userDetails = utils.getUserDetails(userType);
    client.globals.userDetails = userDetails;
    return client.globals.userDetails;
});

Then(/^I end the browser session$/, () => {
    client.end();
});