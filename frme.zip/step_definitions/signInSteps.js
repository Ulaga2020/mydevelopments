'use strict';

const {client} = require('nightwatch-cucumber');
const {When, Then} = require('cucumber');
let signInPage = client.page.signInPage();
let robot = require("robotjs");

When(/^I enter valid username$/, async () => {
    signInPage.waitForElementVisible('@email');
    signInPage.setValue('@email', "vivekanandan.sampath@mrcooper.com");
    return signInPage;
});

Then(/^I click on next button$/, () => {
    signInPage.waitForElementVisible('@next');
    signInPage.click('@next');
    return signInPage;
});
