'use strict';
const {client} = require('nightwatch-cucumber');
const {Then} = require('cucumber');
let landingPage = client.page.landingPage();

Then(/^I verify lead id field is available$/, () => {
    landingPage.waitForElementVisible('@leadIdTextBox');
    return landingPage;
});

Then(/^I enter lead id$/, () => {
    landingPage.waitForElementVisible('@leadIdTextBox');
    landingPage.click('@leadIdTextBox');
    landingPage.clearValue('@leadIdTextBox');
    landingPage.setValue('@leadIdTextBox',client.globals.userDetails["leadId"]);
    return landingPage;
});

Then(/^I click start new tune up button$/, () => {
    landingPage.waitForElementVisible('@startNewTuneUpBtn');
    landingPage.click('@startNewTuneUpBtn');
    return landingPage;
});

Then(/^I click previous tune up link$/, () => {
    landingPage.waitForElementVisible('@previousTuneUps');
    landingPage.click('@previousTuneUps');
    return landingPage;
});

