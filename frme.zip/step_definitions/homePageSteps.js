'use strict';
const {client} = require('nightwatch-cucumber');
const {Then} = require('cucumber');
let homePage = client.page.homePage();

Then(/^I authenticate network user with "([^"]*)" , "([^"]*)" and "([^"]*)"$/, (username, password, mailId) => {
    homePage.navigate('https://' + username + ':' + password +'@sts.nationstarmail.com/adfs/ls/wia?wa=wsignin1.0&wtrealm=urn%3afederation%3aMicrosoftOnline&username=' + mailId);
    return homePage;
});

Then(/^I launch sales desk application$/, () => {
    homePage.navigate(client.globals.launchUrl);
    return homePage;
});

Then(/^I verify sales desk home page is loaded$/, () => {
    homePage.waitForElementVisible('@searchHeading');
    return homePage;
});

Then(/^I verify borrower loan number field is available$/, () => {
    homePage.waitForElementVisible('@searchTextBox');
    return homePage;
});

Then(/^I enter loan number$/, () => {
    homePage.setValue('@searchTextBox',client.globals.userDetails["loanNumber"]);
    return homePage;
});

Then(/^I click search icon$/, () => {
    homePage.waitForElementVisible('@searchIcon');
    homePage.click('@searchIcon');
    return homePage;
});

Then(/^I verify search results are loaded$/, () => {
    homePage.waitForElementVisible('@searchResults');
    return homePage;
});

Then(/^I verify 1st borrower loan number$/, () => {
    homePage.api.useXpath();
    let firstBorrowerLoanNumber = homePage.getBorrowerLoanNumber(client.globals.userDetails["borrowerDetails"]["firstBorrower"]["customerId"]);
    homePage.waitForElementVisible(firstBorrowerLoanNumber);
    homePage.assert.containsText(firstBorrowerLoanNumber,client.globals.userDetails["loanNumber"]);
    homePage.api.useCss();
    return homePage;
});

Then(/^I verify 1st borrower last four digit ssn$/, () => {
    homePage.api.useXpath();
    let firstBorrowerSsn = homePage.getBorrowerSsn(client.globals.userDetails["borrowerDetails"]["firstBorrower"]["customerId"]);
    homePage.waitForElementVisible(firstBorrowerSsn);
    homePage.assert.containsText(firstBorrowerSsn, client.globals.userDetails["borrowerDetails"]["firstBorrower"]["last4DigitSsn"]);
    homePage.api.useCss();
    return homePage;
});

Then(/^I verify 1st borrower full name$/, () => {
    homePage.api.useXpath();
    let firstBorrowerFullName = homePage.getBorrowerName(client.globals.userDetails["borrowerDetails"]["firstBorrower"]["customerId"]);
    homePage.waitForElementVisible(firstBorrowerFullName);
    homePage.assert.containsText(firstBorrowerFullName, client.globals.userDetails["borrowerDetails"]["firstBorrower"]["fullName"]);
    homePage.api.useCss();
    return homePage;
});

Then(/^I click 1st borrower link$/, () => {
    homePage.api.useXpath();
    let firstBorrowerLink = homePage.getBorrowerLink(client.globals.userDetails["borrowerDetails"]["firstBorrower"]["customerId"]);
    homePage.waitForElementVisible(firstBorrowerLink);
    homePage.click(firstBorrowerLink);
    homePage.api.useCss();
    return homePage;
});

