'use strict';
const {client} = require('nightwatch-cucumber');
const {After} = require('cucumber');
let utils = require('../utils');

After(function (scenario) {
    let environments = utils.getEnvironment();
    return client.session(function (session) {
        environments.forEach(async function (env) {
            if (env.slice(-3) === 'cbt') {
                client.end();
                if (scenario.result.status === "passed") {
                    await utils.setCbtScore(session.sessionId, "pass")
                } else {
                    await utils.setCbtScore(session.sessionId, "fail")
                }
            } else {
                client.end();
            }
        });
    });
});