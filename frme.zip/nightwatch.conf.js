const fs = require('fs');
const seleniumServer = require('selenium-server');
const chromeDriver = require('chromedriver');
const geckoDriver = require('geckodriver');
const ieDriver = require('iedriver');
const deepmerge = require('deepmerge');
let utils = require('./utils');

module.exports = (function (settings) {
    settings.selenium = settings.selenium || {};
    settings.selenium.server_path = seleniumServer.path;
    settings.selenium.cli_args = settings.selenium.cli_args || {};
    settings.selenium.start_process = false;
    settings.selenium.cli_args['webdriver.chrome.driver'] = chromeDriver.path;
    settings.selenium.cli_args['webdriver.gecko.driver'] = geckoDriver.path;
    settings.selenium.cli_args['webdriver.ie.driver'] = ieDriver.path;

    let environments = utils.getEnvironment();

    if (!environments.length > 0) {
        environments.push('default') //setting default environment
    }

    let start_process = settings.start_process || false; //default to false is the night-watch behavior

    environments.forEach(env => {
        if (fs.existsSync('./config/' + env + '.json')) {
            if (!settings.test_settings.hasOwnProperty(env)) {
                settings.test_settings[env] = {}
            }
            settings.test_settings[env] = deepmerge(settings.test_settings[env], require('./config/' + env + '.json'))
        }
        if (settings.test_settings[env].hasOwnProperty('start_process')) {
            start_process = start_process || settings.test_settings[env].start_process;
        }
        if (!settings.test_settings.hasOwnProperty(env)) {
            throw new Error(env + 'Environment Not Found')
        }
    });
    settings.selenium.start_process = start_process;
    console.log(`Will the selenium server be started? ${(start_process) ? 'yes' : 'no'}`);
    return settings;
})(require('./nightwatch.json'));
require('nightwatch-cucumber')(module.exports);