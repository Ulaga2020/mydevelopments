module.exports = {
    elements: {
        leadIdTextBox: 'input#new-plan-lead-id',
        startNewTuneUpBtn: 'button#new-plan-link',
        previousTuneUps: 'a.card-item'
    }
};