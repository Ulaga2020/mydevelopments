const util = require('util');
let commands = {
    getBorrowerLoanNumber: function (data) {
        let element = this.elements['loanNumber'];
        return util.format(element.selector, data);
    },
    getBorrowerName: function (data) {
        let element = this.elements['borrowerName'];
        return util.format(element.selector, data);
    },
    getBorrowerSsn: function (data) {
        let element = this.elements['ssn'];
        return util.format(element.selector, data);
    },
    getBorrowerLink: function (data) {
        let element = this.elements['loanLink'];
        return util.format(element.selector, data);
    }
};

module.exports = {
    commands: [commands],
    elements: {
        searchHeading: 'div.question',
        searchTextBox: ' div input',
        searchIcon: 'div button',
        searchResults: 'ul.results',
        loanLink: {
            selector: '//li[@id="borrower_' + '%s' +'"]' + '/a',
            locateStrategy: 'xpath'
        },
        loanNumber: {
            selector: '//li[@id="borrower_' + '%s' +'"]' + '/a/dl/dd[1]',
            locateStrategy: 'xpath'
        },
        borrowerName: {
            selector: '//li[@id="borrower_' + '%s' +'"]' + '/a/dl/dd[2]',
            locateStrategy: 'xpath'
        },
        ssn: {
            selector: '//li[@id="borrower_' + '%s' +'"]' + '/a/dl/dd[3]',
            locateStrategy: 'xpath'
        }
    }
};