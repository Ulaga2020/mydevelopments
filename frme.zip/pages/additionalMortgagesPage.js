module.exports = {
    elements: {
        test: 'test'
    }
};