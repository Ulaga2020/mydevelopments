Apollo HI Automation Setup

Prerequisites:
1.	Install Node.js – Version > 8 (https://nodejs.org/dist/v8.11.3/node-v8.11.3-x64.msi)
    a.	Set Node Install Path in environment variables (C:\Program Files\nodejs)
2.	Install IDE (Recommended WebStorm)
3.	Install GIT (https://git-scm.com/downloads)
    a.	Set GIT Install Path in environment variables (C:\Program Files\Git)

Steps:
1.	Clone the apollo-hi-nightwatch-Automation from VSTS into your local machine
    a.	VSTS Link: https://mrcooper.visualstudio.com/Apollo%20Digital/Apollo%20Digital%20Team/_git/apollo-mrc-nightwatch-automation

2.	Open IDE and Click File->Open->(Project from local)

3.	From Terminal or CMD navigate to the path where “package.json” is available and execute command “npm install” this will install all node modules

4.	To run Feature files
    a.	Single Feature
        Eg. To execute SignIn.feature file run “npm run test -- features/01-SalesDeskHomePage.feature”
    b.	All Feature files
        Eg. Run “npm run test -- features”

5.	By default, the test will execute against “Apollo HI QA” environment https://salesdesk-qa.int.mrcooper.com/hi/

6.	By default, the test will execute in chrome browser provided the browser is installed in the executing machine

7.	We have different environment files under config folder. To run in a specific environment we have to specify the environment in npm run command.
        Eg. “ npm run test -- features/01-SalesDeskHomePage.feature –env hi_test_qa_chrome_local”

8.	Set  “slackNotification = true“ in globals.js to enable slack notification in slack channel
    ” https://apollonationstar.slack.com/messages/CBV163DRR”

9.	Set  “cucumberReport = true“ in globals.js to get html report in reports folder

10.	Add npm debug config under run configuration (if IDE is WebStorm) and attach debug command from package.json to degug the script.

References:
1.	Nightwatch (http://nightwatchjs.org/gettingstarted)
2.	Nightwatch-cucumber (http://mucsi96.github.io/nightwatch-cucumber/#getting-started)
3.	Cucumber (https://docs.cucumber.io/guides/overview/)

